# LINE TCR
# TOBY BOT
Forked from LIN3-TCR [Alfathdirk]

fixing some error and delete unusable code 

## Require to install
```
pip install rsa
pip install request
pip install thrift==0.9.3
```
